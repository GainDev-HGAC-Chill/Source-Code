using System;
using System.Drawing;
using System.Drawing.Imaging;

public partial class rndCreate : System.Web.UI.Page
{
    private void Page_Load(object sender, EventArgs e)
    {
        int imgWidth = int.Parse(Request.QueryString["imgWidth"]);		//가로사이즈
        int imgHeight = int.Parse(Request.QueryString["imgHeight"]);		//세로사이즈
        int imgFontSize = int.Parse(Request.QueryString["imgFontSize"]);	//폰트사이즈
        string imgFont = "Verdana";	//폰트종류
        string strV;	//쿠키로 구어진 값

        strV = (String)Request["q"];

        Bitmap bt = new Bitmap(imgWidth, imgHeight);
        Graphics g = Graphics.FromImage(bt);
		
		//회색바탕의 사각형을 만들기
		SolidBrush backBrush=new SolidBrush(Color.White);
		Rectangle rect=new Rectangle(0,0,imgWidth,imgHeight);
		g.FillRectangle(backBrush,rect);//뒷 배경과 사각형 객체를 전달한다.

        g.DrawString(strV, new Font(imgFont, imgFontSize),
            new SolidBrush(Color.Red), 3, 3);

        Response.ContentType = "image/jpeg";

        bt.Save(Response.OutputStream,
            System.Drawing.Imaging.ImageFormat.Jpeg);   
    }

}
