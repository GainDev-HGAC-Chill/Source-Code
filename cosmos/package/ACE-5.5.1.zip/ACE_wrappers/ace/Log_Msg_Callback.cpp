// Log_Msg_Callback.cpp,v 4.2 2005/10/28 16:14:53 ossama Exp

#include "ace/Log_Msg_Callback.h"

ACE_RCSID(ace, Log_Msg_Callback, "Log_Msg_Callback.cpp,v 4.2 2005/10/28 16:14:53 ossama Exp")


ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Log_Msg_Callback::~ACE_Log_Msg_Callback (void)
{
}
ACE_END_VERSIONED_NAMESPACE_DECL
