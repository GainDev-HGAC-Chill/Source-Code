// Dirent.cpp,v 4.10 2005/01/01 12:14:26 jwillemsen Exp

#include "ace/Dirent.h"

#if !defined (__ACE_INLINE__)
#include "ace/Dirent.inl"
#endif /* __ACE_INLINE__ */
