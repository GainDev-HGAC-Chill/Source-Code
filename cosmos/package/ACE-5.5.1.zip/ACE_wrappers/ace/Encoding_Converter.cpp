// Encoding_Converter.cpp,v 4.1 2006/01/09 15:18:53 elliott_c Exp
#include "ace/Encoding_Converter.h"

#if defined (ACE_USES_WCHAR)
ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Encoding_Converter::~ACE_Encoding_Converter (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
#endif /* ACE_USES_WCHAR */
