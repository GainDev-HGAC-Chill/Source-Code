// Date_Time.cpp
// Date_Time.cpp,v 4.6 2004/06/16 07:57:20 jwillemsen Exp

#include "ace/Date_Time.h"

#if !defined (__ACE_INLINE__)
#include "ace/Date_Time.inl"
#endif /* __ACE_INLINE__ */

ACE_RCSID(ace, Date_Time, "Date_Time.cpp,v 4.6 2004/06/16 07:57:20 jwillemsen Exp")
