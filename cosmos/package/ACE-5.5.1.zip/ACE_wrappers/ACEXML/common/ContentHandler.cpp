#include "ContentHandler.h"


ACE_RCSID (common,
           ContentHandler,
           "ContentHandler.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_ContentHandler::~ACEXML_ContentHandler (void)
{
}
