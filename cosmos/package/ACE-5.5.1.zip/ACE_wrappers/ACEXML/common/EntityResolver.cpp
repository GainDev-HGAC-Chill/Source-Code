#include "EntityResolver.h"


ACE_RCSID (common,
           EntityResolver,
           "EntityResolver.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_EntityResolver::~ACEXML_EntityResolver (void)
{
}
