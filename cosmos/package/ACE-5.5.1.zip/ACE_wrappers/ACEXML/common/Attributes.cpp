#include "Attributes.h"


ACE_RCSID (common,
           Attributes,
           "Attributes.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_Attributes::~ACEXML_Attributes (void)
{
}
