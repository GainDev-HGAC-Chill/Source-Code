#include "ErrorHandler.h"


ACE_RCSID (common,
           ErrorHandler,
           "ErrorHandler.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_ErrorHandler::~ACEXML_ErrorHandler (void)
{
}
